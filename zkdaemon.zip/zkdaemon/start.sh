#!/usr/bin/env bash
# Run the daemon in the foreground (for debugging, or on a host without systemd).
cd "$(dirname "$0")"
exec node index.js "$@"
